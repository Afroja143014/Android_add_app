package com.example.myappl;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText number1;
    private EditText number2;
    private Button b;
    private TextView result;



    @SuppressLint({"MissingSuperCall", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number1= (EditText) findViewById(R.id.textView1);
        number2= (EditText) findViewById(R.id.editTextVew2);
        b=(Button) findViewById(R.id.button);
        result=(TextView) findViewById(R.id.textView3);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1=Integer.parseInt(number1.getText().toString());
                int n2=Integer.parseInt(number2.getText().toString());
                int sum=n1+n2;
                b.setText("Result:"+String.valueOf(sum));

            }
        });

    }
}
